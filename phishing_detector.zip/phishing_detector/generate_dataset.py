"""
generate_dataset.py
--------------------
Builds a labeled dataset of ~11,000 URLs (Legitimate / Phishing) with
realistic structural patterns, then saves it to data/phishing_dataset.csv.

Note: This sandbox cannot reach kaggle.com (network is restricted), so
instead of downloading the Kaggle "Phishing Website Detection" dataset,
this script synthesizes a comparable dataset: legitimate URLs drawn from
real, well-known domains with normal path structures, and phishing URLs
built from patterns genuinely seen in phishing campaigns (IP addresses,
excess subdomains, hyphenated brand lookalikes, suspicious keywords,
URL shorteners, no HTTPS, etc.). Swap this file out for a real CSV loader
if you have access to the actual Kaggle dataset — just make sure the
final dataframe has the same feature columns (see feature_extraction.py)
plus a 'label' column (0 = Legitimate, 1 = Phishing).
"""

import random
import pandas as pd
from feature_extraction import extract_features

random.seed(42)

LEGIT_DOMAINS = [
    "google.com", "youtube.com", "facebook.com", "wikipedia.org", "amazon.com",
    "twitter.com", "instagram.com", "linkedin.com", "microsoft.com", "apple.com",
    "github.com", "stackoverflow.com", "reddit.com", "netflix.com", "yahoo.com",
    "bing.com", "wordpress.com", "adobe.com", "spotify.com", "dropbox.com",
    "paypal.com", "ebay.com", "cnn.com", "bbc.com", "nytimes.com", "quora.com",
    "medium.com", "salesforce.com", "zoom.us", "slack.com", "shopify.com",
    "airbnb.com", "uber.com", "walmart.com", "target.com", "chase.com",
    "wellsfargo.com", "hdfcbank.com", "icicibank.com", "irctc.co.in", "flipkart.com",
]

LEGIT_PATHS = [
    "", "/", "/index.html", "/about", "/products", "/search?q=laptop",
    "/user/profile", "/blog/2024/tech-trends", "/help/faq", "/contact-us",
    "/category/electronics", "/watch?v=abc123", "/docs/getting-started",
    "/news/world", "/settings/account", "/cart", "/checkout", "/careers",
]

BRAND_LOOKALIKES = [
    "paypal", "amazon", "apple", "microsoft", "netflix", "bank", "google",
    "facebook", "chase", "wellsfargo", "irs", "instagram", "outlook",
]

SUSPICIOUS_WORDS = ["login", "verify", "update", "secure", "account",
                     "signin", "confirm", "password", "wallet", "reset"]

RANDOM_TLDS = [".xyz", ".top", ".club", ".info", ".online", ".site", ".biz", ".ru", ".tk"]

SHORTENERS = ["bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "cutt.ly"]


def random_ip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))


def random_string(n):
    letters = "abcdefghijklmnopqrstuvwxyz0123456789"
    return "".join(random.choice(letters) for _ in range(n))


def make_legit_url():
    domain = random.choice(LEGIT_DOMAINS)
    path = random.choice(LEGIT_PATHS)
    scheme = "https://" if random.random() > 0.03 else "http://"
    www = "www." if random.random() > 0.4 else ""
    # occasionally add a benign query param
    if random.random() < 0.15 and "?" not in path:
        path += f"?ref={random_string(5)}"
    return f"{scheme}{www}{domain}{path}"


def make_phishing_url():
    pattern = random.choice(["ip", "subdomain", "hyphen_lookalike", "shortener",
                              "long_random", "suspicious_tld"])
    brand = random.choice(BRAND_LOOKALIKES)
    keyword = random.choice(SUSPICIOUS_WORDS)
    scheme = "http://" if random.random() > 0.25 else "https://"

    if pattern == "ip":
        url = f"{scheme}{random_ip()}/{brand}-{keyword}/{random_string(6)}"
    elif pattern == "subdomain":
        url = f"{scheme}{brand}.{keyword}.{random_string(4)}.com/{random_string(5)}"
    elif pattern == "hyphen_lookalike":
        url = f"{scheme}{brand}-{keyword}-{random_string(4)}.com/{keyword}.php"
    elif pattern == "shortener":
        url = f"{scheme}{random.choice(SHORTENERS)}/{random_string(7)}"
    elif pattern == "long_random":
        url = f"{scheme}{random_string(10)}-{brand}-{random_string(8)}.com/{keyword}/{random_string(10)}"
    else:  # suspicious_tld
        url = f"{scheme}{brand}{keyword}{random.choice(RANDOM_TLDS)}/{random_string(5)}"

    # occasionally add extra noise: @ symbol trick, extra query params, digits
    if random.random() < 0.1:
        url = url.replace("://", "://" + random_string(4) + "@")
    if random.random() < 0.2:
        url += f"?id={random.randint(1000,9999)}&{keyword}=1"

    return url


def build_dataset(n_legit=5500, n_phish=5500):
    rows = []
    seen = set()

    while sum(1 for r in rows if r["label"] == 0) < n_legit:
        url = make_legit_url()
        if url in seen:
            continue
        seen.add(url)
        feats = extract_features(url)
        feats["url"] = url
        feats["label"] = 0
        rows.append(feats)

    while sum(1 for r in rows if r["label"] == 1) < n_phish:
        url = make_phishing_url()
        if url in seen:
            continue
        seen.add(url)
        feats = extract_features(url)
        feats["url"] = url
        feats["label"] = 1
        rows.append(feats)

    random.shuffle(rows)
    df = pd.DataFrame(rows)
    # reorder columns: url, features..., label
    cols = ["url"] + [c for c in df.columns if c not in ("url", "label")] + ["label"]
    return df[cols]


if __name__ == "__main__":
    df = build_dataset()
    df.to_csv("data/phishing_dataset.csv", index=False)
    print(f"Saved {len(df)} rows to data/phishing_dataset.csv")
    print(df["label"].value_counts())
