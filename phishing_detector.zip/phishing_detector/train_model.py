"""
train_model.py
---------------
Loads data/phishing_dataset.csv, preprocesses it, trains Logistic
Regression, Decision Tree, and Random Forest, evaluates all three,
and saves the best model + scaler + metrics so app.py can load them
instantly without retraining.

Run this once before launching the Streamlit app:
    python train_model.py
"""

import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, roc_auc_score, confusion_matrix,
                              roc_curve)

from feature_extraction import FEATURE_NAMES

DATA_PATH = "data/phishing_dataset.csv"
MODEL_DIR = "models"
ASSETS_DIR = "assets"


def load_and_preprocess():
    df = pd.read_csv(DATA_PATH)

    # 1. remove duplicate records
    before = len(df)
    df = df.drop_duplicates()
    print(f"Removed {before - len(df)} duplicate rows")

    # 2. handle missing values (median fill for safety, dataset is synthetic-clean)
    df[FEATURE_NAMES] = df[FEATURE_NAMES].fillna(df[FEATURE_NAMES].median())

    # 3. labels already encoded (0 = Legitimate, 1 = Phishing)
    X = df[FEATURE_NAMES].values
    y = df["label"].values

    # 4. normalize numerical values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # 5. split 80/20
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )
    return X_train, X_test, y_train, y_test, scaler, df


def evaluate(name, model, X_test, y_test):
    preds = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]
    metrics = {
        "accuracy": accuracy_score(y_test, preds),
        "precision": precision_score(y_test, preds),
        "recall": recall_score(y_test, preds),
        "f1": f1_score(y_test, preds),
        "roc_auc": roc_auc_score(y_test, proba),
        "confusion_matrix": confusion_matrix(y_test, preds).tolist(),
    }
    print(f"\n--- {name} ---")
    for k, v in metrics.items():
        if k != "confusion_matrix":
            print(f"{k:10s}: {v:.4f}")
    return metrics, preds, proba


def main():
    X_train, X_test, y_train, y_test, scaler, df = load_and_preprocess()

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=10, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=15, random_state=42),
    }

    all_metrics = {}
    fitted = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        metrics, preds, proba = evaluate(name, model, X_test, y_test)
        all_metrics[name] = metrics
        fitted[name] = (model, proba)

    # pick best model by F1 score
    best_name = max(all_metrics, key=lambda n: all_metrics[n]["f1"])
    best_model = fitted[best_name][0]
    print(f"\nBest model: {best_name}")

    # feature importance (only meaningful for tree-based models)
    if hasattr(best_model, "feature_importances_"):
        importances = dict(zip(FEATURE_NAMES, best_model.feature_importances_.tolist()))
    else:
        importances = dict(zip(FEATURE_NAMES, np.abs(best_model.coef_[0]).tolist()))

    # save model + scaler
    joblib.dump(best_model, f"{MODEL_DIR}/best_model.pkl")
    joblib.dump(scaler, f"{MODEL_DIR}/scaler.pkl")

    # save all models too (so the app can let user compare, optional)
    for name, model in models.items():
        safe_name = name.lower().replace(" ", "_")
        joblib.dump(model, f"{MODEL_DIR}/{safe_name}.pkl")

    # save metrics + metadata as JSON for the Streamlit app
    output = {
        "best_model_name": best_name,
        "all_metrics": all_metrics,
        "feature_importance": importances,
        "feature_names": FEATURE_NAMES,
        "dataset_size": len(df),
        "train_size": len(X_train),
        "test_size": len(X_test),
    }
    with open(f"{MODEL_DIR}/metrics.json", "w") as f:
        json.dump(output, f, indent=2)

    # save confusion matrix + ROC plots for the best model as images
    cm = np.array(all_metrics[best_name]["confusion_matrix"])
    plt.figure(figsize=(4.5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Legitimate", "Phishing"],
                yticklabels=["Legitimate", "Phishing"])
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title(f"Confusion Matrix - {best_name}")
    plt.tight_layout()
    plt.savefig(f"{ASSETS_DIR}/confusion_matrix.png", dpi=140)
    plt.close()

    plt.figure(figsize=(5, 4))
    for name, (model, proba) in fitted.items():
        fpr, tpr, _ = roc_curve(y_test, proba)
        auc = all_metrics[name]["roc_auc"]
        plt.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})")
    plt.plot([0, 1], [0, 1], "k--", alpha=0.4)
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve Comparison")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(f"{ASSETS_DIR}/roc_curve.png", dpi=140)
    plt.close()

    plt.figure(figsize=(6, 5))
    sorted_imp = dict(sorted(importances.items(), key=lambda x: x[1], reverse=True))
    sns.barplot(x=list(sorted_imp.values()), y=list(sorted_imp.keys()), color="#4C72B0")
    plt.title(f"Feature Importance - {best_name}")
    plt.tight_layout()
    plt.savefig(f"{ASSETS_DIR}/feature_importance.png", dpi=140)
    plt.close()

    print("\nSaved model, scaler, metrics.json, and plots to models/ and assets/")


if __name__ == "__main__":
    main()
