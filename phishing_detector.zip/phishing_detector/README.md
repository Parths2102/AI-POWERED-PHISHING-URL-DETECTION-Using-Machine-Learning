# AI-Powered Phishing URL Detection Using Machine Learning

A complete, ready-to-run project: dataset generation → model training →
Streamlit web app that classifies any URL as **Legitimate** or **Phishing**
in real time.

## 📁 What's inside

```
phishing_detector/
├── app.py                  # Streamlit UI (run this to launch the app)
├── train_model.py          # Trains & compares LR / Decision Tree / Random Forest
├── generate_dataset.py     # Builds the labeled training dataset
├── feature_extraction.py   # Shared URL feature-extraction logic
├── requirements.txt
├── data/
│   └── phishing_dataset.csv   # 11,000-row labeled dataset (already generated)
├── models/                 # Trained model, scaler, metrics (already generated)
└── assets/                 # Confusion matrix / ROC / feature-importance plots
```

The dataset, trained model, and charts are **already included** — you can run
the app immediately. Instructions to regenerate everything from scratch are
below too.

## 🚀 Quick start (just run the app)

```bash
# 1. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Launch the app
streamlit run app.py
```

Your browser will open automatically at `http://localhost:8501`.

## 🔁 Regenerate the dataset & retrain (optional)

If you want to rebuild everything from scratch (e.g. after editing
`generate_dataset.py` or `feature_extraction.py`):

```bash
python generate_dataset.py   # rebuilds data/phishing_dataset.csv
python train_model.py        # retrains all 3 models, saves the best one
streamlit run app.py
```

## 🧠 How it works

1. **`generate_dataset.py`** builds ~11,000 URLs: half legitimate (real
   well-known domains with normal paths), half phishing-style (IP-based
   URLs, brand lookalikes with hyphens, suspicious TLDs, URL shorteners,
   excess subdomains, suspicious keywords like *login/verify/update*).
2. **`feature_extraction.py`** turns any URL into 18 numeric features
   (length, dot/hyphen counts, HTTPS flag, IP flag, keyword count, etc.).
   This same file is used both to build the training table and to score
   URLs typed into the app, so training and inference always match.
3. **`train_model.py`** cleans the data, normalizes features, splits
   80/20, trains Logistic Regression / Decision Tree / Random Forest,
   evaluates each on Accuracy / Precision / Recall / F1 / ROC-AUC /
   Confusion Matrix, and saves the best model (by F1-score) plus
   comparison charts.
4. **`app.py`** is a 3-page Streamlit app:
   - **🔎 Detect URL** — type or click an example URL, get an instant
     Legitimate/Phishing verdict with a confidence score and the full
     feature breakdown.
   - **📊 Model Performance** — side-by-side metric table for all three
     algorithms, plus confusion matrix, ROC curve, and feature-importance
     charts.
   - **ℹ️ About Project** — project summary and methodology.

## 📊 Using a real dataset instead

The bundled dataset is synthetically generated (this sandbox has no
internet access to kaggle.com). To plug in the real Kaggle
"Phishing Website Detection" dataset:

1. Download the CSV from Kaggle.
2. Make sure it has a `label` column (0 = Legitimate, 1 = Phishing) and,
   ideally, a `url` column with the raw URL text.
3. If it only has raw URLs, you can regenerate features for it by calling
   `extract_features(url)` from `feature_extraction.py` on each row, or
   swap in the dataset's existing pre-computed features — just make sure
   the column names match `FEATURE_NAMES` in `feature_extraction.py`
   (or edit that list to match the dataset's columns).
4. Save the result as `data/phishing_dataset.csv` and run
   `python train_model.py` again.

## 🛠️ Requirements

- Python 3.9+
- See `requirements.txt` for exact packages.

## ⚠️ Disclaimer

This is an educational/academic project. The bundled dataset is
synthetically generated for demonstration; do not rely on this tool alone
for real-world security decisions.
