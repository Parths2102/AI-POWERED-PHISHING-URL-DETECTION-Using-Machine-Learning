"""
app.py
------
Streamlit UI for the AI-Powered Phishing URL Detection project.

Run with:
    streamlit run app.py

Requires models/best_model.pkl and models/scaler.pkl to already exist.
If they don't, run `python train_model.py` first (see README.md).
"""

import json
import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st

from feature_extraction import extract_features, features_to_vector, FEATURE_NAMES

MODEL_PATH = "models/best_model.pkl"
SCALER_PATH = "models/scaler.pkl"
METRICS_PATH = "models/metrics.json"

st.set_page_config(
    page_title="Phishing URL Detector",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----------------------------------------------------------------------
# Load model artifacts
# ----------------------------------------------------------------------
@st.cache_resource
def load_artifacts():
    if not (os.path.exists(MODEL_PATH) and os.path.exists(SCALER_PATH)):
        return None, None, None
    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    metrics = None
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH) as f:
            metrics = json.load(f)
    return model, scaler, metrics


model, scaler, metrics = load_artifacts()

# ----------------------------------------------------------------------
# Sidebar
# ----------------------------------------------------------------------
with st.sidebar:
    st.title("🛡️ Phishing Detector")
    st.caption("AI-Powered Phishing URL Detection Using Machine Learning")

    if metrics:
        st.success(f"Model loaded: **{metrics['best_model_name']}**")
        st.metric("Test Accuracy", f"{metrics['all_metrics'][metrics['best_model_name']]['accuracy']*100:.2f}%")
        st.metric("Dataset size", f"{metrics['dataset_size']:,} URLs")
    else:
        st.error("Model not found. Run `python train_model.py` first.")

    st.divider()
    page = st.radio("Navigate", ["🔎 Detect URL", "📊 Model Performance", "ℹ️ About Project"])

    st.divider()
    st.caption("Built with Python, Scikit-learn & Streamlit")

# ----------------------------------------------------------------------
# Page: Detect URL
# ----------------------------------------------------------------------
if page == "🔎 Detect URL":
    st.title("🔎 Check a URL for Phishing")
    st.write("Paste any URL below and the trained model will classify it as **Legitimate** or **Phishing**, with a confidence score and a feature breakdown.")

    col1, col2 = st.columns([3, 1])
    with col1:
        url_input = st.text_input(
            "Enter a URL",
            placeholder="e.g. http://paypal-secure-login-update.xyz/verify",
            label_visibility="collapsed",
        )
    with col2:
        check_btn = st.button("Analyze URL", type="primary", use_container_width=True)

    st.caption("Try examples:")
    ex_cols = st.columns(4)
    examples = [
        "https://www.wikipedia.org/wiki/Machine_learning",
        "http://192.168.1.1/login/verify/account",
        "https://secure-paypal-update.tk/signin.php",
        "https://github.com/anthropics",
    ]
    for c, ex in zip(ex_cols, examples):
        if c.button(ex, use_container_width=True):
            url_input = ex
            check_btn = True

    if check_btn and url_input.strip():
        if model is None:
            st.error("Model not trained yet. Run `python train_model.py` in your terminal first.")
        else:
            feats = extract_features(url_input)
            vec = np.array(features_to_vector(url_input)).reshape(1, -1)
            vec_scaled = scaler.transform(vec)
            pred = model.predict(vec_scaled)[0]
            proba = model.predict_proba(vec_scaled)[0]
            confidence = proba[pred] * 100

            st.divider()
            r1, r2 = st.columns([1, 1.4])

            with r1:
                if pred == 1:
                    st.error("### ⚠️ PHISHING DETECTED")
                    st.markdown(f"**Confidence: {confidence:.1f}%**")
                    st.progress(int(confidence))
                    st.warning("Do not enter passwords, card numbers, or personal details on this site.")
                else:
                    st.success("### ✅ LEGITIMATE")
                    st.markdown(f"**Confidence: {confidence:.1f}%**")
                    st.progress(int(confidence))
                    st.info("No strong phishing indicators found, but always stay cautious online.")

                st.markdown("**Class probabilities**")
                prob_df = pd.DataFrame({
                    "Class": ["Legitimate", "Phishing"],
                    "Probability": [proba[0], proba[1]],
                })
                st.bar_chart(prob_df.set_index("Class"))

            with r2:
                st.markdown("**Extracted URL features**")
                feat_df = pd.DataFrame({
                    "Feature": list(feats.keys()),
                    "Value": list(feats.values()),
                })
                st.dataframe(feat_df, use_container_width=True, hide_index=True, height=460)

    elif check_btn:
        st.warning("Please enter a URL first.")

# ----------------------------------------------------------------------
# Page: Model Performance
# ----------------------------------------------------------------------
elif page == "📊 Model Performance":
    st.title("📊 Model Performance & Comparison")

    if metrics is None:
        st.error("No metrics found. Run `python train_model.py` first.")
    else:
        st.subheader("Algorithm comparison")
        rows = []
        for name, m in metrics["all_metrics"].items():
            rows.append({
                "Model": name,
                "Accuracy": f"{m['accuracy']*100:.2f}%",
                "Precision": f"{m['precision']*100:.2f}%",
                "Recall": f"{m['recall']*100:.2f}%",
                "F1-score": f"{m['f1']*100:.2f}%",
                "ROC-AUC": f"{m['roc_auc']*100:.2f}%",
            })
        cmp_df = pd.DataFrame(rows)
        st.dataframe(cmp_df, use_container_width=True, hide_index=True)
        st.caption(f"⭐ Best performing model: **{metrics['best_model_name']}** "
                    f"(selected by highest F1-score, trained on {metrics['train_size']:,} URLs, "
                    f"tested on {metrics['test_size']:,} URLs)")

        st.divider()
        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown("**Confusion Matrix**")
            if os.path.exists("assets/confusion_matrix.png"):
                st.image("assets/confusion_matrix.png", use_container_width=True)
        with c2:
            st.markdown("**ROC Curve Comparison**")
            if os.path.exists("assets/roc_curve.png"):
                st.image("assets/roc_curve.png", use_container_width=True)
        with c3:
            st.markdown("**Feature Importance**")
            if os.path.exists("assets/feature_importance.png"):
                st.image("assets/feature_importance.png", use_container_width=True)

        st.divider()
        st.subheader("Metric bar chart")
        metric_names = ["accuracy", "precision", "recall", "f1", "roc_auc"]
        chart_data = pd.DataFrame({
            name: [metrics["all_metrics"][name][m] for m in metric_names]
            for name in metrics["all_metrics"]
        }, index=metric_names)
        st.bar_chart(chart_data)

# ----------------------------------------------------------------------
# Page: About
# ----------------------------------------------------------------------
else:
    st.title("ℹ️ About This Project")
    st.markdown("""
### AI-Powered Phishing URL Detection Using Machine Learning

Phishing attacks trick users into visiting fake websites that mimic trusted
services (banks, e-commerce, social media) to steal credentials and personal
data. Traditional blacklists can't catch brand-new phishing sites — this
project uses **machine learning on URL structure alone** to catch previously
unseen phishing attempts in real time, without needing to visit the site.

**Pipeline**
1. **Data collection & preprocessing** — duplicate removal, missing-value
   handling, encoding, normalization, 80/20 train-test split.
2. **Feature engineering** — 18 lexical features per URL: length, dot/hyphen
   counts, HTTPS usage, digit/special-character counts, IP-address
   detection, URL-shortener detection, subdomain count, and suspicious
   keyword count (login, verify, update, secure, account, etc.).
3. **Model training** — Logistic Regression, Decision Tree, and Random
   Forest, compared on Accuracy, Precision, Recall, F1-score, ROC-AUC, and
   Confusion Matrix.
4. **Deployment** — the best model (highest F1-score) is used here to score
   any URL you type in, live.
""")
    if metrics:
        st.markdown(f"""
**Current run stats**
- Dataset size: {metrics['dataset_size']:,} URLs
- Training set: {metrics['train_size']:,} URLs
- Test set: {metrics['test_size']:,} URLs
- Best model: **{metrics['best_model_name']}**
""")
    st.markdown("""
**Note on the dataset:** the bundled `data/phishing_dataset.csv` is
generated by `generate_dataset.py` using realistic legitimate-domain and
phishing-pattern rules (IP-based URLs, brand lookalikes, suspicious TLDs,
shorteners, excess subdomains, etc.). To use a real dataset such as the
Kaggle "Phishing Website Detection" dataset instead, download the CSV,
make sure it has the same feature columns as `feature_extraction.py`
plus a `label` column (0 = Legitimate, 1 = Phishing), save it to
`data/phishing_dataset.csv`, and re-run `python train_model.py`.
""")
