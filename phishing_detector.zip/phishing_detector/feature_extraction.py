"""
feature_extraction.py
----------------------
Extracts URL-based lexical features used to classify a URL as
Legitimate or Phishing. Used identically by train_model.py (to build
the training table) and app.py (to score a URL typed by the user),
so training and inference always stay in sync.
"""

import re
from urllib.parse import urlparse

SUSPICIOUS_KEYWORDS = ["login", "verify", "update", "secure", "account",
                        "signin", "bank", "confirm", "password", "wallet"]

SHORTENER_DOMAINS = ["bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly",
                      "is.gd", "buff.ly", "adf.ly", "shorte.st", "cutt.ly"]

IP_PATTERN = re.compile(r"^(https?://)?(\d{1,3}\.){3}\d{1,3}")

FEATURE_NAMES = [
    "url_length",
    "hostname_length",
    "path_length",
    "count_dots",
    "count_hyphens",
    "count_at",
    "count_question",
    "count_percent",
    "count_ampersand",
    "count_equal",
    "count_underscore",
    "count_digits",
    "count_special_chars",
    "num_subdomains",
    "has_https",
    "has_ip",
    "has_shortener",
    "suspicious_keyword_count",
]


def _safe_parse(url: str):
    """Parse a URL, adding a scheme if missing so urlparse behaves."""
    if not re.match(r"^https?://", url, re.IGNORECASE):
        url_for_parse = "http://" + url
    else:
        url_for_parse = url
    return urlparse(url_for_parse)


def extract_features(url: str) -> dict:
    """Given a raw URL string, return a dict of numeric features."""
    url = url.strip()
    parsed = _safe_parse(url)
    hostname = parsed.netloc or ""
    path = parsed.path or ""

    special_chars = sum(1 for c in url if not c.isalnum() and c not in [".", "/", ":"])
    subdomains = hostname.split(".")
    # crude subdomain count: total labels minus domain+tld (assume 2 = domain+tld)
    num_subdomains = max(0, len(subdomains) - 2)

    features = {
        "url_length": len(url),
        "hostname_length": len(hostname),
        "path_length": len(path),
        "count_dots": url.count("."),
        "count_hyphens": url.count("-"),
        "count_at": url.count("@"),
        "count_question": url.count("?"),
        "count_percent": url.count("%"),
        "count_ampersand": url.count("&"),
        "count_equal": url.count("="),
        "count_underscore": url.count("_"),
        "count_digits": sum(c.isdigit() for c in url),
        "count_special_chars": special_chars,
        "num_subdomains": num_subdomains,
        "has_https": 1 if url.lower().startswith("https") else 0,
        "has_ip": 1 if IP_PATTERN.match(url) else 0,
        "has_shortener": 1 if any(s in hostname.lower() for s in SHORTENER_DOMAINS) else 0,
        "suspicious_keyword_count": sum(kw in url.lower() for kw in SUSPICIOUS_KEYWORDS),
    }
    return features


def features_to_vector(url: str):
    """Return features as an ordered list matching FEATURE_NAMES."""
    f = extract_features(url)
    return [f[name] for name in FEATURE_NAMES]
